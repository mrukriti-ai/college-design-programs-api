"""
API service module for communicating with the FastAPI backend.
Handles all API calls, error handling, and data formatting.
"""

import requests
import streamlit as st
from typing import Dict, List, Any, Optional
from utils.config import get_api_url, get_api_headers, get_admin_headers

def test_api_connection() -> bool:
    """Test if the API is accessible"""
    try:
        response = requests.get(get_api_url("/health"), timeout=10)
        return response.status_code == 200
    except Exception as e:
        st.error(f"API connection failed: {str(e)}")
        return False

def get_colleges(filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Get colleges from the API with optional filters"""
    try:
        if filters:
            response = requests.get(
                get_api_url("/api/colleges/search"), 
                params=filters, 
                headers=get_api_headers(),
                timeout=30
            )
        else:
            response = requests.get(
                get_api_url("/api/colleges"), 
                headers=get_api_headers(),
                timeout=30
            )
        
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, dict) and 'colleges' in data:
                return data['colleges']
            elif isinstance(data, list):
                return data
            else:
                return []
        else:
            st.error(f"API error: {response.status_code} - {response.text}")
            return []
            
    except requests.exceptions.Timeout:
        st.error("API request timed out. Please try again.")
        return []
    except requests.exceptions.ConnectionError:
        st.error("Cannot connect to API. Please check your internet connection.")
        return []
    except Exception as e:
        st.error(f"Unexpected error: {str(e)}")
        return []

def get_college_by_id(college_id: int) -> Optional[Dict[str, Any]]:
    """Get a specific college by ID"""
    try:
        response = requests.get(
            get_api_url(f"/api/colleges/{college_id}"), 
            headers=get_api_headers(),
            timeout=30
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"College not found: {response.status_code}")
            return None
            
    except Exception as e:
        st.error(f"Error fetching college: {str(e)}")
        return None

def search_colleges(
    program_type: Optional[str] = None,
    location: Optional[str] = None,
    budget_range: Optional[str] = None,
    degree_level: Optional[str] = None,
    limit: int = 50
) -> List[Dict[str, Any]]:
    """Search colleges with specific criteria"""
    
    filters = {}
    if program_type and program_type != "Any":
        filters['program_type'] = program_type
    if location and location != "Any":
        filters['location'] = location
    if budget_range and budget_range != "Any":
        filters['budget_range'] = budget_range
    if degree_level and degree_level != "Any":
        filters['degree_level'] = degree_level
    
    filters['limit'] = limit
    
    return get_colleges(filters)

def get_program_types() -> List[str]:
    """Get available program types from API"""
    try:
        response = requests.get(
            get_api_url("/api/colleges/program-types"), 
            headers=get_api_headers(),
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            # Fallback to default program types
            return ["Graphic Design", "UX/UI", "Fashion", "Product Design", "Architecture", "Animation"]
            
    except:
        # Fallback to default program types
        return ["Graphic Design", "UX/UI", "Fashion", "Product Design", "Architecture", "Animation"]

def get_locations() -> List[str]:
    """Get available locations from API"""
    try:
        response = requests.get(
            get_api_url("/api/colleges/locations"), 
            headers=get_api_headers(),
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            # Fallback to default locations
            return ["North America", "Europe", "Asia", "Australia", "Any"]
            
    except:
        # Fallback to default locations
        return ["North America", "Europe", "Asia", "Australia", "Any"]

def get_budget_ranges() -> List[str]:
    """Get available budget ranges from API"""
    try:
        response = requests.get(
            get_api_url("/api/colleges/budget-ranges"), 
            headers=get_api_headers(),
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            # Fallback to default budget ranges
            return ["Under 20k", "20k-40k", "40k-60k", "Over 60k"]
            
    except:
        # Fallback to default budget ranges
        return ["Under 20k", "20k-40k", "40k-60k", "Over 60k"]

def get_degree_levels() -> List[str]:
    """Get available degree levels from API"""
    try:
        response = requests.get(
            get_api_url("/api/colleges/degree-levels"), 
            headers=get_api_headers(),
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            # Fallback to default degree levels
            return ["Bachelor", "Master", "Certificate", "Any"]
            
    except:
        # Fallback to default degree levels
        return ["Bachelor", "Master", "Certificate", "Any"]

def upload_excel_file(file_content: bytes, filename: str) -> bool:
    """Upload Excel file to API for admin purposes"""
    try:
        files = {'file': (filename, file_content, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
        response = requests.post(
            get_api_url("/api/admin/upload-excel"),
            files=files,
            headers=get_admin_headers(),
            timeout=60
        )
        
        if response.status_code == 200:
            st.success("Excel file uploaded successfully!")
            return True
        else:
            st.error(f"Upload failed: {response.status_code} - {response.text}")
            return False
            
    except Exception as e:
        st.error(f"Upload error: {str(e)}")
        return False

def get_api_status() -> Dict[str, Any]:
    """Get API status and health information"""
    try:
        response = requests.get(get_api_url("/health"), timeout=10)
        if response.status_code == 200:
            return response.json()
        else:
            return {"status": "unhealthy", "error": f"HTTP {response.status_code}"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
